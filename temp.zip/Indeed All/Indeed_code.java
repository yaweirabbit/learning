1.find local peak

	public static void main(String[] arg) {
		int[] a = {8, 5, 3, 6, 1, 4, 7};
		for(int i = 1; i + 1 < a.length; i++) {
			if(a[i] < a[i - 1] && a[i] < a[i + 1]) {
				System.out.println(i);
				break;
			}
		}
		System.out.println(binarySearch(a, 1, a.length  - 2));
		
	}
	//like if border can as peak side
	//If num[i-1] < num[i] < num[i+1], then num[i+1...n-1] must contains a peak
	//If num[i-1] > num[i] > num[i+1], then num[0...i-1] must contains a peak
	public int findPeakElement(int[] nums) {
		int i = 0, j = nums.length - 1, max = -1;
		while(i <= j) {
			int mid = (i + j) / 2;
			if((mid == 0 || nums[mid] > nums[mid - 1]) 
				&& (mid == nums.length - 1 || nums[mid] > nums[mid + 1]))
				return mid;
			else if(mid == 0 || nums[mid] >nums[mid - 1]) {
				i = mid + 1;
			}
			else {
				j = mid - 1;
			}
		}
		return i;
	}

2. add lags
		String s = "There is all in all, two all", t = "all";
		StringBuffer res = new StringBuffer();
		for(int i = 0; i < s.length();) {
			StringBuffer cur = new StringBuffer();
			while(i < s.length() && Character.isAlphabetic(s.charAt(i))){
				cur.append(s.charAt(i));
				i++;
			}
			if(t.equals(cur.toString())) {
				res.append("<b>" + cur.toString() + "</b>");
			}
			else res.append(cur.toString());
			while(i < s.length() && !Character.isAlphabetic(s.charAt(i))) {
				res.append(s.charAt(i));
				i++;
			}
		}
		System.out.println(res.toString());

3. find duplicates
/*1. lz答首先处理成全部小写，然后把单词分隔开，
可以用trie来省内存（要是内存放不下还可以放进disk），
然后说了一下因为现实中有些词出现次数很多但是没什么意义的，
比如I, you, he, she这些，可以另外设置一个filter来把这些不valuable的输出过滤掉（小哥表示赞同），
最后又补充了可以多台机器一起做。（小哥表示对的你是不是有什么distributed system的经验，其实lz并没有，我就说之后有project会涉及到所以有点点了解）
2. 第一问 hashset  第二问 hashmap存最早的index
*/
		//Set
		HashSet<String> data = new HashSet<>();
		String s = "abc def ghi abc";
		String[] str = s.toLowerCase().split(" ");
		for(String c : str) {
			if(data.contains(c))
				System.out.println(c);
			data.add(c);
		}
		
		//trie to  save space
		trie head = new trie();
		for(String c : str) {
			trie cur = head;
			for(char l : c.toCharArray()) {
				int idx = l - 'a';
				if(cur.next[idx] == null)
					cur.next[idx] = new trie();
				cur = cur.next[idx];
			}
			if(cur.isWord)
				System.out.println(c);
			cur.isWord = true;
		}

	//first one
	class trie {
		//int idx = -1;
		boolean isWord;
		trie[] next;
		public trie() {
			isWord = false;
			next = new trie[26];
	}
}

public class test {
	

	public static void main(String[] arg) {
		//Set
		HashMap<String, Integer> data = new HashMap<>();
		String s = "abc def ghi def ghi abc";
		String[] str = s.toLowerCase().split(" ");
		int res = str.length;
		for(int i = 0; i < str.length; i++) {
			if(data.containsKey(str[i])) {
				int b = data.get(str[i]);
				//update idx for the very first
				res = Math.min(res, b);
			}
			else data.put(str[i], i);
		}
		System.out.println(str[res]);
		
		//trie to  save space for same prefix
		trie head = new trie();
		res = str.length;
		for(int i = 0; i < str.length; i++) {
			String c = str[i];
			trie cur = head;
			for(char l : c.toCharArray()) {
				int idx = l - 'a';
				if(cur.next[idx] == null)
					cur.next[idx] = new trie();
				cur = cur.next[idx];
			}
			//update idx for the very first
			if(cur.isWord) {
				res = Math.min(res, cur.idx);
			}
			else {
				cur.isWord = true;
				cur.idx = i;
			}
		}
		System.out.println(str[res]);
	}



4.ExpiringMap
package ink;

import java.util.*;

public class ExpiringMap {
	
	public class E {
		int val;
		long duration;
		long endTime;
		public E(int val, long duration) {
			this.val = val;
			this.duration = duration;
			this.endTime = System.currentTimeMillis() + duration;
		}
	}
	
	HashMap<Integer, E> data;
	
	public ExpiringMap() {
		data = new HashMap<>();
	}
	
	public void put(int key, int val, long duration) {
		data.put(key, new E(val, duration));
	}
	
	public Integer get(int key) {
		if(!data.containsKey(key))
			return null;
		E value = data.get(key);
		if(value.endTime >= System.currentTimeMillis()) {
			data.remove(key);
			return null;
		}
		else return value.val;
	}

}


package ink;

import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class ExpiringMap {
	
	public class E {
		int val;
		int key;
		long duration;
		long endTime;
		public E(int key, int val, long duration) {
			this.key = key;
			this.val = val;
			this.duration = duration;
			this.endTime = System.currentTimeMillis() + duration;
		}
	}
	
	HashMap<Integer, E> data;
	PriorityQueue<E> q;
	
	public ExpiringMap() {
		data = new HashMap<>();
		////default integer compare
		q = new PriorityQueue<>((a, b) -> Long.compare(b.endTime, a.endTime));
	}
	
	//also can use PQ to store element
	//nlog(n), log(n) for every poll or add
	//update the database periodically
	public void update() {
		////use queue
		while(!q.isEmpty() && q.peek().endTime >= System.currentTimeMillis()) {
			E cur = q.poll();
			data.remove(cur.key);
		}
	}
	
	//just put
	public void put(int key, int val, long duration) {
		data.put(key, new E(key, val, duration));
	}
	
	//see if out of time
	public Integer get(int key) {
		if(!data.containsKey(key))
			return null;
		E value = data.get(key);
		if(value.endTime >= System.currentTimeMillis()) {
			data.remove(key);
			return null;
		}
		else return value.val;
	}

}



package ink;

import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class ExpiringMap {
	
	public class E {
		int val;
		long duration;
		long endTime;
		public E(int val, long duration) {
			this.val = val;
			this.duration = duration;
			this.endTime = System.currentTimeMillis() + duration;
		}
	}
	
	HashMap<Integer, E> data;
	
	Lock lock;
	
	public ExpiringMap() {
		data = new HashMap<>();
		/*
		 * 可重入公平锁获取流程

		在获取锁的时候，如果当前线程之前已经获取到了锁，就会把state加1，
		在释放锁的时候会先减1，这样就保证了同一个锁可以被同一个线程获取多次，而不会出现死锁的情况。
		这就是ReentrantLock的可重入性。

		对于非公平锁而言，调用lock方法后，会先尝试抢占锁，
		在各种判断的时候会先忽略等待队列，如果锁可用，就会直接抢占使用。
		 */
		lock = new ReentrantLock();
	}
	
	//update the database periodically
	//may need a locker 
	//if we  would like to periodically update in practice
	public void update() {
		try {
			if(lock.tryLock(10, TimeUnit.SECONDS)) {
				
				//what need to be updated
				List<Integer> rm = new LinkedList<>();
				for(Integer key : data.keySet()) {
					long time = System.currentTimeMillis();
					if(data.get(key).endTime >= time)
						rm.add(key);
				}
				for(Integer key : rm)
					data.remove(key);               
				
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			lock.unlock();
		}
	}

	public void static main(String[] arg) {

		ExpiringMap tes = new ExpiringMap();

		Thread t1 = new Thread(new Runnable() {
		    @Override
		    public void run() {
		        tes.update();
	            try {
					Thread.sleep(100);
				} catch (Exception e) {
					e.printStackTrace();
				}
		    }
		});  
		t1.start();
	}

}



5. matrix find zero coordinate

package tt;

import java.util.*;


public class test {
	
	static int[][] grid = {{1, 1, 1, 1}, {1, 0, 0, 0}, {1, 0, 0, 0}, {1, 1, 1, 1}};
	
	public static void main(String[] arg) {
		List<int[][]> res = findZero(grid);
		for(int[][] cur : res) {
			System.out.println(cur[0][0] + " " + cur[0][1]);
			System.out.println(cur[1][0] + " " + cur[1][1]);
		}
	}
	
	static int row;
	static int column;


	//function find corrdinate
	//public static List<List<int[]> findZero2(int[][] grid) {
	public static List<int[][]> findZero(int[][] grid) {
		row = grid.length;
		column = grid[0].length;
		
		//first
		List<int[][]> res = new LinkedList<>();
		
		//second
		//List<List<int[]>> res2 = new LinkedList<>();
		
		
		for(int i = 0; i < row; i++) {
			for(int j = 0; j < column; j++) {
				
				if(grid[i][j] == 0) {
					//first
					res.add(find(i, j, grid));
					
					//second
					//List<int[]> cur = new LinkedList<>();
					//findZ(i, j, grid, cur);
					//res2.add(cur);
				}
			}
		}
		return res;
	}




	//first rectangle
	public static int[][] find(int r, int c, int[][] grid) {
		int e1 = -1, e2 = -1;
		for(int i = r; i < row; i++) {
			if(grid[i][c] != 0) {
				e1 = i - 1;
				break;
			}
			for(int j = c; j < column; j++) {
				if(grid[i][j] == 0)
					grid[i][j] = 1;
				else {
					e2 = j - 1;
					break;
				}
			}
			if(e2 == -1) e2 = column - 1;
		}
		if(e1 == -1) e1 = row - 1;
		return new int[][] {{r, c},{e1, e2}};
	}



	
	//second dfs
	static int[][] moves = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
	
	//original
	public static void findZ(int r, int c, int[][] grid, List<int[]> cur) {
		cur.add(new int[] {r, c});
		//update visited
		grid[r][c] = 1;
		for(int[] move : moves) {
			int i = r + move[0], j = c + move[1];
			if(i >= 0 && i < row && j >= 0 && j < column && grid[i][j] == 0) {
				findZ(i, j, grid, cur);
			}
		}
	}
	
}


6. 小于某个target的最大sum
	//only for all positive value
		int[] nums = {3, 1, 4, 11, 2, 4, 8, 4, 1, 2, 4};
		int t = 8;
		
		int res = 0, sum = 0;
		Queue<Integer> q = new LinkedList<>();
		for(int i = 0; i < nums.length; i++) {
			sum += nums[i];
			q.add(nums[i]);
			while(sum >= t) {
				sum -= q.poll();
			}
			res = Math.max(res, sum);
		}
		System.out.println(res);


		
		res = 0; sum = 0; int slow = 0;
		for(int i = 0; i < nums.length; i++) {
			sum += nums[i];
			while(sum >= t) {
				sum -= nums[slow++];
			}
			res = Math.max(res, sum);
		}       
		
		
		System.out.println(res);


7.//Intersection of Two Arrays
//merge sorted array



class Solution {
	public int[] intersection(int[] nums1, int[] nums2) {
		HashSet<Integer> set1 = new HashSet<>();
		for(int n : nums1) {
			set1.add(n);
		}
		HashSet<Integer> set2 = new HashSet<>();
		for(int n : nums2) {
			if(set1.contains(n))
				set2.add(n);
		}
		int[] res = new int[set2.size()];
		int index = 0;
		for(int n : set2) {
			res[index++] = n;
		}
		return res;
	}
}


class Solution {
	public int[] intersection(int[] nums1, int[] nums2) {
		Arrays.sort(nums1);
		Arrays.sort(nums2);
		int i = 0, j = 0;
		List<Integer> res = new LinkedList<>();
		//merge sort
		while(i < nums1.length && j < nums2.length) {
			//for intersection, if we find one record, and move forward
			//until finding another one different element
			if(nums1[i] == nums2[j]) {
				int cur = nums1[i];
				res.add(cur);
				while(i < nums1.length && nums1[i] == cur)
					i++;
				while(j < nums2.length && nums2[j] == cur)
					j++;
			}
			//merge
			else if(nums1[i] > nums2[j])
				j++;
			else i++;
		}
		int[] is = new int[res.size()];
		int idx = 0;
		for(int n : res)
			is[idx++] = n;
		return is;
	}
}


//intersection k sorted list 
//The runtime seems like its nlogk?
//In the heap the maximum number of elements will be k. 
//Hence every operation w/r/t is log(k)

//The while loop runs for n times. 
//(until all the elements in the linked list has been added to the heap and extracted out)

//therefore its n*logk

class Mlist {
	int idx;
	List<Integer> list;
	public Mlist(int idx, List<Integer> list) {
		this.idx = idx;
		this.list = list;
	}
}

public static void main(String[] arg) {
	int[][] data = {{1, 1, 2, 3, 3, 4, 4, 5}, {1, 1,3,3, 3, 4, 4, 5, 5, 5, 5}, {1, 1, 2, 3, 4, 5, 6, 6, 6}};
	List<List<Integer>> d = new LinkedList<>();
	for(int[] l : data) {
		List<Integer> cur = new LinkedList<>();
		for(int n : l)
			cur.add(n);
		d.add(cur);
	}
	List<Integer> res = interN(d);
	for(int n : res) {
		System.out.print(n + " ");
	}
}

//to record current idx for heap
//merge n list

private static List<Integer> interN(List<List<Integer>> lists) {
	List<Integer> res = new LinkedList<>();
	
	int len = lists.size();
	if(len < 1) return res;
	
	//create a heap, the value to compare is the current index element in each list
	PriorityQueue<Mlist> q = new PriorityQueue<>((a, b) -> (a.list.get(a.idx) - b.list.get(b.idx)));
	for(List<Integer> list : lists) {
		if(list.size() > 0) {
			q.add(new Mlist(0, list));
		}
		//if there is an empty list return empty list
		else return res;
	}
	
	//merge the list in the queue
	while(!q.isEmpty()) {
		//get peek list, and set value for this layer for search
		Mlist cur = q.peek();
		int val = cur.list.get(cur.idx), count = 0;
		
		//loop to find list have same value
		while(!q.isEmpty() && cur.list.get(cur.idx) == val) {
			count++;
			//poll the current peek out
			cur = q.poll();
			//skip duplicates
			while(cur.idx < cur.list.size() && cur.list.get(cur.idx) == val) {
				cur.idx++;
			}
			//if not reach the end, continue
			if(cur.idx < cur.list.size())
				q.add(cur);
			cur = q.peek();
		}
		//if each list has this element, update interseaction
		if(count == len)
			res.add(val);
	}
	return res;
}


8. move average
stream


import java.util.*;

public class MovingAverage {
	
	class E{
		public long endTime;
		int val;
		public E(int val, long endTime) {
			this.val = val;
			this.endTime = endTime;
		}
	}
	
	Queue<E> data = new LinkedList<>();
	long windowSize;
	////double sum;
	
	public MovingAverage() {
		////sum = 0;
	}
	
	public void record(int value) {
		//record value and time
		data.add(new E(value, System.currentTimeMillis() + windowSize));
		////sum += value;
	}
	
	//get mean
	public double mean() {
		//remove expired elements
		update();
		double sum = 0, len = data.size();
		for(int i = 0; i < len; i++) {
			E cur = data.poll();
			sum += cur.val;
			data.add(cur);
		}
		return sum / len;
		
		/*
		 * update();
		 * return sum / data.size();
		 * 
		 */
	}
	
	//update to remove elements out of time
	public void update() {
		//may need a locker if we  would like to periodically update in practice
		while(!data.isEmpty() && data.peek().endTime >= System.currentTimeMillis()) {
			data.poll();
			////E cur = data.poll();
			////sum -= cur.val;
		}
	}
	
	/**
	 * if like have a time for each one, we need a priorityqueue to store by endTime
	 */
}

9
class Solution {
	public int repeatedStringMatch(String A, String B) {
		int[] next = new int[B.length()];
		for(int i = 0, j = 1; j < B.length();) {
			if(B.charAt(i) == B.charAt(j)) {
				//update idx for
				next[j++] = i + 1;
				//update for nextchar
				i++;
			}
			else {
				//move forward to find prefix
				if(i == 0)
					j++;
				//else move to next position where
				//the slower pointer will just adjust
				// to the prefix
				//"aabaaac"
				else i = next[i - 1];
			}
		}
		StringBuffer sb = new StringBuffer();
        for(int i = 1; sb.length() < A.length() * 2 + B.length(); i++) {
            sb.append(A);
            if(kmp(sb.toString(), B, next))
                return i;
        }
        return -1;
	}
	
	//store prefix and posfix
	//The Knuth-Morris-Pratt Algorithm
	int kmp(String A, String B, int[] next) {
		if(A.length() < B.length())
			return 0;
		int res = 0;
		for(int i = 0, j = 0; i < A.length() && j < B.length();) {
			if(A.charAt(i) == B.charAt(j)) {
				i++;
				j++;
				if(j == B.length()) {
					res++;
					//move the pointer of B
					j = next[j - 1];
				}
			}
			else {
				if(j == 0)
					i++;
				else j = next[j - 1];
			}
		}
		return res;
	}
}

10.
reverse string html entity
	int idx = 0;
	while(idx < s.length()) {
		if(s.charAt(idx) != '&')
			res.append(s.charAt(idx));
		else {
			//record nearest & and starter of idx
			int start = idx, pre = idx;
			while(idx < s.length() && s.charAt(idx) != ';') {
				if(s.charAt(idx) == '&')
					pre = idx;
				idx++;
			}
			//; not found, add all
			if(idx == s.length())
				res.append(s.substring(start));
			else {
				//append previous one
				res.append(s.substring(start, pre));
				//reverse
				res.append(new StringBuffer(s.substring(pre, idx + 1)).reverse().toString());
			}
		}
		idx++;
	}
	int i = 0, j = s.length() - 1;
	char[] str = res.toString().toCharArray();
	while(i <= j) {
		char t = str[i];
		str[i] = str[j];
		str[j] = t;
		i++;
		j--;
	}
	System.out.println(new String(str));


11.summary range
	public List<String> summaryRanges(int[] nums) {
		List<String> res = new LinkedList<>();
		for(int i = 0; i < nums.length; i++) {
			Integer cur = nums[i], pre = cur;
			//loop to find contiguous number
			while(i + 1 < nums.length && nums[i + 1] == cur + 1) {
				cur = nums[i + 1];
				i++;
			}
			//if not found next one
			if(cur == pre) {
				res.add(String.valueOf(cur));
			}
			else {
				res.add(pre + "->" + cur);
			}
		}
		return res;
	}


	//find breaking point
	//d = nums[0] - 0;
	int bs(int[] nums, int s, int e, int d) {
		while(s <= e) {
			int mid = (s - e) / 2 + e;
			//find breaking point, mid - 1 could never be zero
			//if is already > d, cause d = nums[0] = 0;
			if(nums[mid] > mid + d && nums[mid - 1] == mid + d - 1)
				return mid;
			else if(nums[mid] > mid + d)
				e = mid -1;
			else s = mid + 1;
		}
		return -1;
	}


//dupliacte
class Solution {
	public List<String> summaryRanges(int[] nums) {
		nums = new int[] {1, 2, 3, 3, 4, 4, 6, 6, 6, 7, 7, 9};
		List<String> res = new LinkedList<>();
		if(nums.length == 0) return res;
		//initiate start number
		Integer s = nums[0], pre = nums[0];
		for(int i = 1; i < nums.length; i++) {
			//if the same number, continue
			if(nums[i] == pre)
				continue;
			//if the next contigous number, record as pre
			else if(nums[i] == pre + 1)
				pre = nums[i];
			else if(nums[i] > pre + 1) {
				//avoid compare overflow
				if((long)pre == (long)s)
					res.add(String.valueOf(pre));
				//add these range of number
				else res.add(s + "->" + pre);
				//update for next ramge
				s = nums[i];
				pre = nums[i];
			}
		}
		//update the last range
		if((long)pre == (long)s)
			res.add(String.valueOf(pre));
		else res.add(s + "->" + pre);
		return res;
	}
}

// with no order, within o(n)
class Solution {
	public List<String> summaryRanges(int[] nums) {
		//nums = new int[] {-2, -1, 0, 1, 2, 3, 3, 4, 4, 6, 6, 6, 7, 7, 9};
		List<String> res = new LinkedList<>();
		if(nums.length == 0) return res;
		HashSet<Integer> set = new HashSet<>();
		for(int n : nums) set.add(n);
		HashSet<Integer> visited = new HashSet<>();
		for(int n : set) {
			if(!visited.contains(n)) {
				visited.add(n);
				int l = n, r = n;
				while(set.contains(l - 1)) {
					l--;
					visited.add(l);
				}
				while(set.contains(r + 1)) {
					r++;
					visited.add(r);
				}
				if(l == r)
					res.add(String.valueOf(n));
				else res.add(l + "->" + r);
			}
		}
		return res;
	}
}


12.Palindrome Permutation II

O(n^n), n=s.length()/2, O(1) * 178

class Solution {
    
    List<String> res;
    
    public List<String> generatePalindromes(String s) {
        int[] data = new int[178];
        for(char l : s.toCharArray())
            data[l]++;
        //half each freq
        int mid = -1, len = 0;
        for(int i = 0; i < 178; i++) {
        	//only one mid is allowed
            if(data[i] % 2 != 0) {
                if(mid != -1)
                    return new LinkedList<String>();
                mid = i;
            }
            len += data[i];
            data[i] = data[i] / 2;
        }
        res = new LinkedList<>();
        build(data, new StringBuffer(), mid == -1 ? "" : String.valueOf((char)mid), len);
        return res;
    }
    
    //
    private void build(int[] data, StringBuffer cur, String mid, int len) {
        if(cur.length() == len / 2) {
            res.add(cur.toString() + mid + cur.reverse().toString());
            return;
        }
        for(int i = 0; i < 178; i++) {
            if(data[i] > 0) {
                data[i]--;
                build(data, new StringBuffer(cur.toString()).append((char)i), mid, len);
                data[i]++;
            }
        }
    }
}


//remove character not in freq list
class Solution {
    
    List<String> res;
    class E {
        int freq;
        char val;
        public E(char l, int f) {
            val = l;
            freq = f;
        }
    }
    
    public List<String> generatePalindromes(String s) {
        int[] data = new int[178];
        for(char l : s.toCharArray())
            data[l]++;
        int mid = -1, len = 0;
        List<E> letters = new ArrayList<>();
        for(int i = 0; i < 178; i++) {
            if(data[i] % 2 != 0) {
                if(mid != -1)
                    return new LinkedList<String>();
                mid = i;
            }
            len += data[i];
            letters.add(new E((char)i, data[i] / 2));
        }
        res = new LinkedList<>();
        build(letters, new StringBuffer(), mid == -1 ? "" : String.valueOf((char)mid), len);
        return res;
    }
    
    private void build(List<E> letters, StringBuffer cur, String mid, int len) {
        if(cur.length() == len / 2) {
            res.add(cur.toString() + mid + cur.reverse().toString());
            return;
        }
        for(int i = 0; i < letters.size(); i++) {
            E e = letters.get(i);
            if(e.freq > 0) {
                e.freq--;
                build(letters, new StringBuffer(cur.toString()).append(e.val), mid, len);
                e.freq++;
            }
        }
    }
}

13.separate character
O(n)*26, maxi(ni.length)

    private static List<List<Character>> separate(List<Character> list) {
    	List<List<Character>> res = new LinkedList<>();
    	if(list.size() < 1) return res;
    	//record freq in an array
    	int[] data = new int[26];
    	//maxi frequency
    	int max = 0;
    	for(char l : list) {
    		data[l - 'a']++;
    		max = Math.max(max, data[l - 'a']);
    	}
    	//loop through the array
    	for(int i = 0; i < max; i++) {
    		List<Character> cur = new LinkedList<>();
    		for(int j = 0; j < 26; j++) {
    			if(data[j] > 0) {
    				cur.add((char)(j + 'a'));
    				data[j]--;
    			}
    		}
    		res.add(cur);
    	}
    	return res;
    }

//if Standard Deviation for frequency is very large
    private static List<List<Character>> separate(List<Character> list) {
    	List<List<Character>> res = new LinkedList<>();
    	if(list.size() == 0) return res;
    	//hashmap store frequency
    	HashMap<Character, Integer> map = new HashMap<>();
    	int len = 0;
    	for(Character l : list) {
    		map.put(l, map.getOrDefault(l, 0) + 1);
    		len = Math.max(len, map.get(l));
    	}
    	//loop to create
    	for(int i = 0; i < len; i++) {
    		//each time create new list by keyset
    		List<Character> cur = new LinkedList<>(map.keySet());
    		//delete any character been used up
    		for(Character l : cur) {
    			map.put(l, map.get(l) - 1);
    			if(map.get(l) == 0)
    				map.remove(l);
    		}
    		res.add(cur);
    	}
    	return res;
    }

14. valid Python
    public static void main(String[] arg) {
    	String[] a = {"#dsa", "#dffdf:", "fnd sh fb", "if a  d:", "  d f", "  sd", "#fd:"};
    	System.out.println(validPython(a));
    }
    
    private static boolean validPython(String[] str) {
    	//if nothing inside
    	if(str.length == 0 || str == null)
    		return true;
    	
    	//use stack to store previous 
    	Stack<Integer> st = new Stack<>();
    	//user preidx for previous lines to skip quotation(pound sign)
    	int preIdx = -1;
    	for(int i = 0; i < str.length; i++) {
    		String cur = str[i];
    		
    		//get space number
    		int space = countS(cur);
    		//detect if this is a quotation, skip
    		if(cur.charAt(space) == '#') {
    			continue;
    		}
    		
    		
    		//record first statement without quotation
    		if(preIdx == -1 ) {
    			if(space > 0) {
    				System.out.println("first statement without quotation");
    				return false;
    			}
    			preIdx = i;
    		}
    		//flowwing lines
    		else {
    			String pre = str[preIdx];
    			//if there should be a indentation
    			if(pre.charAt(pre.length() - 1) == ':') {
    				//if previous have more indentation
    				if(st.empty() || st.peek() >= space) {
    					System.out.println("if previous have more indentation");
    					return false;
    				}
    			}
    			else {
    				//if not in this module
    				if(space > st.peek()) {
    					System.out.println(i + cur + "if not in this module " + pre);
    					return false;
    				}
    				//pop out previous space 
    				//to find lines with same indentation
    				//like if a > b: a = 1 b++
    				while(!st.empty() && st.peek() > space) {
    					st.pop();
    				}
    				//if not found same indentation lines
    				if(st.empty() || st.peek() != space) {
    					System.out.println("if not found same indentation lines");
    					return false;
    				}
    			}
    			preIdx = i;
    		} 

			st.push(space);
    	}
    	
    	//if last one's last is ":", 
    	//but nothing follows by the control statement
    	String last = str[preIdx];
    	if(last.charAt(last.length() - 1) == ':') {
    		System.out.println("nothing follows by the control statement");
    		return false;
    	}
    	
    	return true;
    }
    
    //count space in the front
    private static int countS(String s) {
    	int count = 0;
    	for(int i = 0; i < s.length(); i++) {
    		if(s.charAt(i) == ' ')
    			count++;
    		else break;
    	}
    	return count;
    }

15.merge sort

//remove duplicates
private static List<Integer> mergeTwo(List<Integer> one, List<Integer> two) {
	List<Integer> res = new LinkedList<>();
	int l1 = one.size(), l2 = two.size();
	if(l1 == 0 || l2 == 0)
		return res;
	int i = 0, j = 0;
	while(i < l1 || j < l2) {
		int cur;
		//if add element from first
		if(i == l1 || (j < l2 && one.get(i) > two.get(j))) {
			cur = two.get(j);
			while(j < l2 && two.get(j) == cur)
				j++;
		}
		//if add element from second
		else if(j == l2 || one.get(i) < two.get(j)) {
			cur = one.get(i);
			while(i < l1 && one.get(i) == cur)
				i++;
		}
		//if two values are the same 
		else{
			cur = one.get(i);
			while(j < l2 && two.get(j) == cur)
				j++;
			while(i < l1 && one.get(i) == cur)
				i++;
		}
		res.add(cur);
	}
	return res;
}


merge k sorted list into one list of integer
package tt;

import java.util.*;


public class test {
	
    public static void main(String[] arg) {
    	int[][] data = {{1, 2, 4, 5}, {2, 4, 5, 8}, {1, 5, 9, 10}, {2, 534, 4343, 32333}};
    	List<List<Integer>> d = new LinkedList<>();
    	for(int[] l : data) {
    		List<Integer> cur = new LinkedList<>();
    		for(int n : l)
    			cur.add(n);
    		d.add(cur);
    	}
    	List<Integer> res = mergeN(d);
    	for(int n : res) {
    		System.out.print(n + " ");
    	}
    }
    
    //to record current idx for heap
    //merge n list
    
    private static List<Integer> mergeN(List<List<Integer>> lists) {
    	List<Integer> res = new LinkedList<>();
    	if(lists.size() < 1) return res;
    	
    	//create a heap, the value to compare is the current index element in each list
    	PriorityQueue<Mlist> q = new PriorityQueue<>((a, b) -> (a.list.get(a.idx) - b.list.get(b.idx)));
    	for(List<Integer> list : lists) {
    		if(list.size() > 0) {
    			q.add(new Mlist(0, list));
    		}
    	}
    	
    	//merge the list in the queue
    	while(!q.isEmpty()) {
    		Mlist cur = q.poll();
    		//update index
    		res.add(cur.list.get(cur.idx++));
    		if(cur.idx < cur.list.size())
    			q.add(cur);
    	}
    	return res;
    }
    
}

class Mlist {
	int idx;
	List<Integer> list;
	public Mlist(int idx, List<Integer> list) {
		this.idx = idx;
		this.list = list;
	}
}


16.excel sheet column title
class Solution {
    public String convertToTitle(int n) {
        String res = "";
        while(n != 0) {
            res = (char)((n - 1) % 26 + 'A') + res;
            n = (n - 1) / 26;
        }
        return res;
    }
}

17.store binary tree
1/3


public class test {
    
    private static Integer[] pressTree(TreeNode root) {
    	int length = mark(root, 1);
    	Integer[] res = new Integer[length];
    	store(res, root, 1);
    	return res;
    }
    
    private static void store(Integer[] res, TreeNode root, int key) {
    	if(root == null)
    		return;
    	res[key - 1] = root.val;
    	store(res, root.left, key * 2);
    	store(res, root.right, key * 2 + 1);
    }
    private static int mark(TreeNode root, int key) {
    	if(root.left == null && root.right == null)
    		return key;
    	int res = 0;
    	if(root.left != null)
    		res = Math.max(res, mark(root.left, 2 * key));
    	if(root.right != null)
    		res = Math.max(res, mark(root.right, 2 * key + 1));
    	return res;
    }
    
    
    private static TreeNode extract(Integer[] res, int key) {
    	if(key > res.length || res[key - 1] == null)
    		return null;
    	TreeNode root = new TreeNode(res[key - 1]);
    	root.left = extract(res, 2 * key);
    	root.right = extract(res, 2 * key + 1);
    	return root;
    }
    
}

    public static void main(String[] arg) {
    	TreeNode c = new TreeNode(1);
    	c.right = new TreeNode(2);
    	c.right.left = new TreeNode(3);
    	c.right.left.left = new TreeNode(4);
    	c.right.left.right = new TreeNode(5);
    	c.right.left.right.left = new TreeNode(6);
    	Integer[] tree = pressTree(c);
    	for(Integer n : tree) {
    		System.out.print(n + " ");
    	}
    	tree = pressTree(extract(tree, 1));
    	System.out.println();
    	for(Integer n : tree) {
    		System.out.print(n + " ");
    	}
    	
    	//use hashmap only store idx and value which is not null
    	HashMap<Integer, Integer> data = new HashMap<>();
    	for(int i = 0; i < tree.length; i++) {
    		if(tree[i] != null)
    			data.put(i, tree[i]);
    	}
    }

class TreeNode {
	int val;
	TreeNode left;
	TreeNode right;
	public TreeNode(int val) {
		this.val = val;
	}
}

18 Two sum
two pointer, also O(n)
class Solution {
    public int[] twoSum(int[] numbers, int target) {
        int[] res = new int[2];
        int i = 0, j = numbers.length - 1;
        while(i < j){
            int sum = numbers[i] + numbers[j];
            if(sum == target) {
                res = new int[]{i + 1, j + 1};
                break;
            }
            else if(sum > target) j--;
            else i++;
        }
        return res;
    }
}

19
https://leetcode.com/problems/median-of-two-sorted-arrays/discuss/2481/Share-my-O(log(min(mn))-solution-with-explanation
Median of Two Sorted Arrays
O(N)
class Solution {
    public double findMedianSortedArrays(int[] nums1, int[] nums2) {
        int len = nums1.length + nums2.length;
        int i = 0, j = 0;
        List<Integer> res = new ArrayList<>();
        while(i < nums1.length || j < nums2.length) {
            int cur;
            if(i == nums1.length || (j < nums2.length && nums2[j] < nums1[i])) {
                cur = nums2[j];
                j++;
            }
            else {
                cur = nums1[i];
                i++;
            }
            res.add(cur);
        }
        double sum = res.get(len/2) + res.get((len - 1)/2);
        return sum / 2;
    }
}

O(logn)
public double findMedianSortedArrays(int[] A1, int[] A2) {
    int len1 = A1.length, len2 = A2.length;
    int mid1 = (len1 + len2 + 1) / 2, mid2 = (len1 + len2 + 2) / 2;
    // Every time call getkth can reduce the scale k to its half.
    // So the time complexity is log(m + n).
    return (findKth(A1, 0, len1, A2, 0, len2, mid1) + findKth(A1, 0, len1, A2, 0, len2, mid2)) / 2;
}

private double findKth(int[] A1, int s1, int m, int[] A2, int s2, int n, int k) {
	//default A1 always smaller than A2
    if (m > n) return findKth(A2, s2, n, A1, s1, m, k);
    //current length of A1 is zero, just return kth smallest
    if (m == 0) return A2[s2 + k - 1];
    //if the first smallest, just return head of two arrays
    if (k == 1) return Math.min(A1[s1], A2[s2]);
    
    ////确定使用二分法，确定前进步长为k / 2, split find
    //split each array by half of k
    int i = Math.min(m, k / 2), j = Math.min(n, k / 2);
    ////确定搜索方向。。s > l。。那么 s 往小的方向发展。
    //l 往大的方向发展。。所以，代码实现 l 往大的方向发展这一步就好。
    if (A1[s1 + i - 1] < A2[s2 + j - 1]) {
    	//cut elements in A1 before s1 + i
    	//cut k by half, ignore those smaller elements
        return findKth(A1, s1 + i, m - i, A2, s2, n, k - i);
    } else {
    	//cut elements in A2 before s2 + j
        return findKth(A1, s1, m, A2, s2 + j, n - j, k - j);
    }
}

20
basic calculator
https://leetcode.com/problemset/all/?search=basic%20cal

class Solution {
    public int calculate(String s) {
        Stack<Integer> st = new Stack<>();
        int num = 0, sign = 1, res = 0;
        st.add(sign);
        for(int i = 0; i < s.length(); i++) {
            char cur = s.charAt(i);
            if(Character.isDigit(cur)) {
                num = 10 * num + (cur - '0');
            }
            else if(cur == '(') {
                st.push(sign);
            }
            else if(cur == ')') {
                st.pop();
            }
            else if(cur == '-' || cur == '+') {
                res += (num * sign);
                num = 0;
                if(cur == '-') {
                sign = st.peek() * -1;
                }
                else if(cur == '+') {
                sign = st.peek() * 1;
                }
            }
        }
        if(num != 0)
            res += num * sign;
        return res;
    }
}

//expression with value
public static String calculate(String s, String[] re, int[] val) {
	
	//store value of expression
	HashMap<String, Integer> map = new HashMap<>();
	for(int i = 0; i < val.length; i++) {
		map.put(re[i], val[i]);
	}
	
	//use stack store signs
    Stack<Integer> st = new Stack<>();
    int num = 0, sign = 1, res = 0;
    st.add(sign);
    
    //store expression in order
    StringBuffer exp = new StringBuffer();
    //compare second for store of signs
    TreeSet<String> front = new TreeSet<>((a, b) -> a.substring(1).compareTo(b.substring(1)));
    
    
    for(int i = 0; i < s.length(); i++) {
        char cur = s.charAt(i);
        //build expression
        if(Character.isAlphabetic(cur)) {
        	exp.append(cur);
        }
        //build number
        else if(Character.isDigit(cur)) {
            num = 10 * num + (cur - '0');
        }
        //push previous sign
        else if(cur == '(') {
            st.push(sign);
        }
        else if(cur == ')') {
            st.pop();
        }
        else if(cur == '-' || cur == '+') {
        	if(exp.length() > 0) {
        		String exp1 = exp.toString();
        		//have value
        		if(map.containsKey(exp1))
        			res += (map.get(exp1) * sign);
        		//no value
        		else front.add((sign == 1 ? "+" : "-") + exp1);
        		exp = new StringBuffer();
        	}
        	else res += (num * sign);
            num = 0;
            if(cur == '-') {
            	sign = st.peek() * -1;
            }
            else if(cur == '+') {
            	ßsign = st.peek() * 1;
            }
        }
    }
    
    //deal with last number
    if(num != 0)
        res += num * sign;
    //deal with last string expression
	if(exp.length() > 0) {
		String exp1 = exp.toString();
		if(map.containsKey(exp1))
			res += (map.get(exp1) * sign);
		else front.add((sign == 1 ? "+" : "-") + exp1);
	}
	
	//build result
	StringBuffer r = new StringBuffer();
	for(String str : front)
		r.append(str);
	if(r.length() > 0) {
		r.append((res > 0 ? "+" : "") + res);
	}
	else r.append(res);
	
	//check fron plus
	if(r.charAt(0) == '+')
		return r.substring(1);
	return r.toString();
}


Least Recently Used
Red–black tree balanced binary search
